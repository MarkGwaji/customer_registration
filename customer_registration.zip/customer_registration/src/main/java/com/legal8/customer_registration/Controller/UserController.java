package com.legal8.customer_registration.Controller;

import com.legal8.customer_registration.Entity.User;
import com.legal8.customer_registration.Entity.UserData;
import com.legal8.customer_registration.Exception.ResourceNotFoundException;
import com.legal8.customer_registration.Repository.UserDataRepository;
import com.legal8.customer_registration.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@Validated
@RequestMapping("/customer")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserDataRepository userDataRepository;

    // get all users
    @GetMapping("/customerinfo")
    public List<User> getAllUsers() {
        return this.userRepository.findAll();
    }

    // get user by id
    @GetMapping("customerinfo/{id}")
    public User getUserById(@PathVariable(value = "id") long userId) {
        return this.userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id :" + userId));
    }

    // create user
    @PostMapping("register")
    public User createUser(@Valid @RequestBody User user, UserData userData) {

        userDataRepository.save(userData);
        return this.userRepository.save(user);
    }

    // update user
    @PutMapping("/update/{id}")
    public User updateUser(@Valid @RequestBody User user, @RequestBody UserData userData, @PathVariable ("id") long userId) {
        User existingUser = this.userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id :" + userId));

        UserData existingUserData = this.userDataRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id :" + userId));

        existingUser.setFirstName(user.getFirstName());
        existingUserData.setFirstName(userData.getFirstName());

        existingUser.setLastName(user.getLastName());
        existingUserData.setLastName(userData.getLastName());

        existingUser.setDateOfBirth(user.getDateOfBirth());
        existingUserData.setDateOfBirth(userData.getDateOfBirth());

        existingUser.setEmail(user.getEmail());
        existingUserData.setEmail(userData.getEmail());

        existingUser.setPhoneNumber(user.getPhoneNumber());
        existingUserData.setPhoneNumber(userData.getPhoneNumber());

        existingUser.setAddress(user.getAddress());
        existingUserData.setAddress(userData.getAddress());

        existingUser.setCountry(user.getCountry());
        existingUserData.setCountry(userData.getCountry());

        existingUser.setCurrency(user.getCurrency());
        existingUserData.setCurrency(userData.getCurrency());

        this.userDataRepository.save(existingUserData);

        return this.userRepository.save(existingUser);
    }

    // delete user by id
    @DeleteMapping("delete/{id}")
    public ResponseEntity<User> deleteUser(@PathVariable ("id") long userId){
        User existingUser = this.userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id :" + userId));

        UserData existingUserData =this.userDataRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id :" + userId));

        existingUserData.setStatus("Deactivated");
        existingUserData.setDateDeleted(ZonedDateTime.of(LocalDateTime.now(), ZoneId.of("Africa/Johannesburg")));
        this.userDataRepository.save(existingUserData);
        this.userRepository.delete(existingUser);
        return ResponseEntity.ok().build();
    }

}
