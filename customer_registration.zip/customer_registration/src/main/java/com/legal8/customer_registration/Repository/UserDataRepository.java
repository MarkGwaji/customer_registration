package com.legal8.customer_registration.Repository;

import com.legal8.customer_registration.Entity.UserData;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserDataRepository extends JpaRepository<UserData, Long> {
}
